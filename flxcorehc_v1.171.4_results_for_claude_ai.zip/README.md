# FlxCoreHC v1.171.4 — independent runtime results (Claude Code)

Files:
1. FLXCOREHC_v1.171.4_RUNTIME_REPORT.md — the report (read this first). Every check labelled
   EXECUTED — PASS / EXECUTED — FAIL / STATICALLY REVIEWED / REQUIRES EXTERNAL RUNTIME VALIDATION,
   verbatim output for every non-PASS, reviewer items (address back-fill HEX, memory, shared-NAT login),
   surprising observations, and the full runtime_check.sh output in Appendix A.
2. runtime_check_output_v1.171.4.txt — raw output of `bash tools/runtime_check.sh`
   (pristine tree, FLX_CONFIG set, app/config.php absent). Exit 1: stage 3f failed.
3. http_smoke_supplementary_v1.171.4.txt — stage 3f re-run with app/config.php present (supplementary, ALL PASS).
4. screenshots/ — A_* (Steps 3b–3d), B_* (Steps 3e–3h, 4).

Environment: PHP 8.4.19, MariaDB 10.11.14, python 3.11.15, Chromium via Playwright, php -S.
No application code, tests, SQL or docs were modified.

Not-PASS items to address: Step 2 stage 3f (index.php:5 ignores FLX_CONFIG), 3d-2, 3d-6, 3e-2, 3e-3, 3g-1, 3h-3.
