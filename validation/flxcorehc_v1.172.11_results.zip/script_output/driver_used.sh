#!/usr/bin/env bash
# FlxCoreHC v1.172.11 — independent validation driver for Claude Code. RUN + REPORT ONLY: never edits the app, migrations or tests.
# Usage:  DB_USER=root DB_PASS=secret [DB_HOST=127.0.0.1] [DB_PORT=3306] bash claude_code_validate_v1_172_11.sh /path/to/flxcorehc-v1_172_11.zip
# Needs: php 8.3+ (pdo_mysql), python3, mysql client, unzip, a THROW-AWAY MariaDB/MySQL server (creates/drops flx_* databases). Never production.
set -u
ZIP="${1:-flxcorehc-v1_172_11.zip}"; [ -f "$ZIP" ] || { echo "zip not found: $ZIP"; exit 2; }
WORK="$(mktemp -d)"; APP="$WORK/app_tree"; OUT="$PWD/flxcorehc_v1.172.11_results"; mkdir -p "$OUT" "$APP"
unzip -q "$ZIP" -d "$APP" || exit 2
{
echo "== environment =="; php -v | head -1; mysql --version; python3 --version; date -u
echo "== precondition: no app/config.php in the package =="
n=$(find "$APP" -path '*app/config.php' | wc -l); echo "app/config.php count: $n"; [ "$n" = 0 ] || echo "FAIL: package contains app/config.php"
} 2>&1 | tee "$OUT/00_environment.txt"
CFG="$WORK/test_config.php"
php -r '$c=["db_host"=>getenv("DB_HOST")?:"127.0.0.1","db_port"=>(int)(getenv("DB_PORT")?:3306),"db_user"=>getenv("DB_USER")?:"root","db_pass"=>getenv("DB_PASS")?:"","db_name"=>"flx_smoke","app_env"=>"dev","app_key"=>str_repeat("0",64),"app_timezone"=>"America/Puerto_Rico","docs_path"=>$argv[2]."/docs","app_url"=>"http://localhost"]; @mkdir($c["docs_path"],0750,true); file_put_contents($argv[1],"<?php return ".var_export($c,true).";\n");' "$CFG" "$WORK"
export FLX_CONFIG="$CFG"
cd "$APP" || exit 2
echo "== runtime_check (app/config.php ABSENT, FLX_CONFIG=$CFG) =="
bash tools/runtime_check.sh 2>&1 | sed 's/\x1b\[[0-9;]*m//g' | tee "$OUT/01_runtime_check_output.txt"
rc=${PIPESTATUS[0]}; echo "runtime_check exit code: $rc" | tee "$OUT/02_exit_code.txt"
{ echo "== stray files =="; ls -A app/storage; echo "== config.php present after run? =="; ls app/config.php 2>&1; echo "== summary =="; grep -cE '^PASS' "$OUT/01_runtime_check_output.txt" | sed 's/^/PASS lines: /'; grep -nE '^FAIL|: FAIL|STARTUP ERROR|SKIPPED|SKIP\(' "$OUT/01_runtime_check_output.txt" || echo "no FAIL/SKIP lines"; } 2>&1 | tee "$OUT/03_summary.txt"
cat > "$OUT/04_browser_checks_TODO.md" <<'EOT'
# Still to do by hand (cannot be automated here)
Follow docs/architecture/CLAUDE_CODE_RUNTIME_CHECK.md Steps 1, 3b, 3c, 3d, 3g, 3h, 3i, 3j, 3k, 4 in a browser against a real install.
Report each: EXECUTED — PASS / EXECUTED — FAIL / REQUIRES BROWSER VALIDATION. List anything surprising. Do not fix anything.
EOT
(cd "$(dirname "$OUT")" && zip -qr "$(basename "$OUT").zip" "$(basename "$OUT")") && echo "Results: $OUT.zip (send this to Claude.ai)"
exit $rc
