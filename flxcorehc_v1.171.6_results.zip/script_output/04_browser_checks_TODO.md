# Still to do by hand (cannot be automated here)
Follow docs/architecture/CLAUDE_CODE_RUNTIME_CHECK.md Steps 1, 3b, 3c, 3d, 3g, 3h, 3i, 4 in a browser against a real install.
Report each: EXECUTED — PASS / EXECUTED — FAIL / REQUIRES BROWSER VALIDATION. List anything surprising. Do not fix anything.
